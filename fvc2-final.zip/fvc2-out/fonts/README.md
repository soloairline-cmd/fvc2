# /fonts — Self-hosted Web Fonts

Run `./DOWNLOAD-FONTS.sh` once to download the 7 `.woff2` files:

| File | Family | Weight |
|------|--------|--------|
| `playfair-display-v700-latin.woff2` | Playfair Display | 700 |
| `playfair-display-v800-latin.woff2` | Playfair Display | 800 |
| `playfair-display-v900-latin.woff2` | Playfair Display | 900 |
| `manrope-v400-latin.woff2` | Manrope | 400 |
| `manrope-v500-latin.woff2` | Manrope | 500 |
| `manrope-v600-latin.woff2` | Manrope | 600 |
| `manrope-v700-latin.woff2` | Manrope | 700 |

These files are served from `/fonts/` with:
`Cache-Control: public, max-age=31536000, immutable`
(configured in `_headers`)

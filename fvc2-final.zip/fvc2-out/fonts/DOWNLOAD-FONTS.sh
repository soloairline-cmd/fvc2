#!/bin/bash
# ============================================
# FRANCE VITAMINE C — Font Downloader
# À exécuter UNE FOIS à la racine du projet
# Télécharge les 7 polices woff2 dans ./fonts/
# ============================================
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

dl() { echo "  ⬇ $1"; curl -s -A "$UA" -o "$DIR/$1" "$2"; }

echo "📦 Playfair Display..."
dl playfair-display-v700-latin.woff2 "https://fonts.gstatic.com/s/playfairdisplay/v37/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKd3vUDQZNLo_U2r.woff2"
dl playfair-display-v800-latin.woff2 "https://fonts.gstatic.com/s/playfairdisplay/v37/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKdFvUDQZNLo_U2r.woff2"
dl playfair-display-v900-latin.woff2 "https://fonts.gstatic.com/s/playfairdisplay/v37/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKdsvUDQZNLo_U2r.woff2"

echo "📦 Manrope..."
dl manrope-v400-latin.woff2 "https://fonts.gstatic.com/s/manrope/v15/xn7_YHE41ni1AdIRqAuZuw1Bx9mbZk59FO_F87jxeN7B.woff2"
dl manrope-v500-latin.woff2 "https://fonts.gstatic.com/s/manrope/v15/xn7_YHE41ni1AdIRqAuZuw1Bx9mbZk5PFO_F87jxeN7B.woff2"
dl manrope-v600-latin.woff2 "https://fonts.gstatic.com/s/manrope/v15/xn7_YHE41ni1AdIRqAuZuw1Bx9mbZk6jE-_F87jxeN7B.woff2"
dl manrope-v700-latin.woff2 "https://fonts.gstatic.com/s/manrope/v15/xn7_YHE41ni1AdIRqAuZuw1Bx9mbZk6aE-_F87jxeN7B.woff2"

echo ""
echo "✅ Fonts ready:"
ls -lh "$DIR"/*.woff2
